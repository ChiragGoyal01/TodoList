First create vite project using npm create vite@latest
then choose project name and else things
then enter into vite project using cd vite-project
then run npm install for node modules and package.lock.json 
then run using npm run dev
