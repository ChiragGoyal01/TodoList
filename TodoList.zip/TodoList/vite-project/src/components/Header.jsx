import React, { useState } from "react";

const Header = ({ addToDo }) => {
  const [text, setText] = useState("");

  const handleAdd = () => {
    if (text.trim()) {
      addToDo(text);
      setText("");
    }
  };

  return (
    <header>
      <h1 className="Header-title">To-Do List</h1>
      <input
        type="text"
        placeholder="Add a new task..."
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <button onClick={handleAdd}>Add</button>
    </header>
  );
};

export default Header;
